<?php

	// Defining Constants
	define( 'HOST', 'localhost' );
	define( 'DB', 'learning_management' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>