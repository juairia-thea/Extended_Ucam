<!DOCTYPE html>
<html>
  <body> 
    <body style="background-color:white;"></body>
    </br>   
    </br>
	<style>
		h1 {text-align: center;}
		h3 {text-align: center;}
		p {text-align: center;}
		div {text-align: center;}
	</style>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <nav style="background-color: orange;width: auto;height: 80px;">
        <div style="color: white;text-align: center; font-size: 32px; font-weight: bold; padding-top: 20px;">Extended
            UCAM</div>

    </nav>
    <body style="background-color:white;"></body>
	<h1>Provide Information</h1>



<form method=get action=provideInfo_result.php>
<h3>
	Student ID : <input type=text name=student_id> <br>

	<p>

	Course Code : <input type=text name=course_code> <br>

	<p>

	<h3><input type=submit value=Submit>
</h1>
</form>

  </body>
</html>

